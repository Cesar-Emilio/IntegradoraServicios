export interface TypeUser {
    jwt:        string;
    userId:     number;
    username:   string;
    admin:      string;
    expiration: number;
}
